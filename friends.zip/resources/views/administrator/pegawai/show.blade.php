<table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Item</th>
        <th>Keterangan</th>
      </tr>
    </thead>
    <tbody>
    <tr>
        <td></td>
        <td>Nama</td>
        <td>{{$data['nama']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Nomor Induk Pegawai</td>
        <td>{{$data['nip']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Jenis Kelamin</td>
        <td>{{$data['jk']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Tanggal Lahir</td>
        <td>{{$data['tgl_lahir']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Agama</td>
        <td>{{$data['agama']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Status</td>
        <td>{{$data['status']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Masa Kerja</td>
        <td>{{$data['masa_kerja']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Jumlah Jam</td>
        <td>{{$data['jml_jam']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Tugas Tambahan</td>
        <td>{{$data['tgs_tambahan']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Alamat</td>
        <td>{{$data['alamat']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>No Telepon</td>
        <td>{{$data['no_tlp']}}</td>
    </tr>
    </tbody>
  </table>
<table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Item</th>
        <th>Keterangan</th>
      </tr>
    </thead>
    <tbody>
    <tr>
        <td></td>
        <td>Nama</td>
        <td>{{$data['nama']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Nomor Induk Siswa</td>
        <td>{{$data['nis']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Kelas</td>
        <td>{{$data['kelas']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Jenis Kelamin</td>
        <td>{{$data['jk']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Tanggal Lahir</td>
        <td>{{$data['tgl_lahir']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Agama</td>
        <td>{{$data['agama']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Anak Ke</td>
        <td>{{$data['anak_ke']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Status</td>
        <td>{{$data['status']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Pendidikan Sebelumnya</td>
        <td>{{$data['pend_sblmnya']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Alamat Siswa</td>
        <td>{{$data['tgs_tambahan']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Ayah</td>
        <td>{{$data['ayah']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Ibu</td>
        <td>{{$data['ibu']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Wali Ayah</td>
        <td>{{$data['wali_ayah']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>Wali Ibu</td>
        <td>{{$data['wali_ibu']}}</td>
    </tr>
    <tr>
        <td></td>
        <td>No Telepon</td>
        <td>{{$data['no_telp']}}</td>
    </tr>
    </tbody>
  </table>
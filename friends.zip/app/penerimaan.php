<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class penerimaan extends Model
{
    protected $table = 'tb_penerimaan';
}

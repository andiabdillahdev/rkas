<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bukuPembantuBank extends Model
{
    protected $table = 'tb_pmb_bank';
}

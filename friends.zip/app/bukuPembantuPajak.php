<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bukuPembantuPajak extends Model
{
    protected $table = 'buku_pmb_pajak';
}

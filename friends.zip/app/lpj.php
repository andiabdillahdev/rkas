<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lpj extends Model
{
    protected $table = 'tb_lpj';
}

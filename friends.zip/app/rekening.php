<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rekening extends Model
{
    protected $table = 'tb_rekening';
}

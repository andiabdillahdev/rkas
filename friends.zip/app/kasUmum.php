<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kasUmum extends Model
{
    protected $table = 'tb_kas';
}

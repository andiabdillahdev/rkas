<?php $__env->startSection('konten'); ?>
<div class="right_col" role="main">
    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3>LPJ (Laporan Pertanggung Jawaban) </h3>
        </div>
      </div>

      <div class="clearfix"></div>

      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>LPJ</h2>
              <div class="clearfix"></div>
            </div>
            <div class="x_content">              
             
                <form id="formdataLpj">
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th>Preview</th>
                        <th>Tanggal Di Kirim</th>
                        <th>Status LPJ</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                              <a role="button" href="<?php echo e(route('preview.lpj')); ?>"><i class="fa fa-file-pdf-o"></i> Lihat Rekapitulasi</a>
                          </td>
                          <td>
                              <?php echo e($item['tanggal']); ?>

                          </td>
                          <td>
                              <?php if($item['status'] == 'Belum Di Periksa'): ?>
                              <span class="label label-warning"><i class="fa fa-warning"></i> <?php echo e($item['status']); ?></span>
                              <?php elseif($item['status'] == 'Revisi'): ?>
                              <span class="label label-danger"><i class="fa fa-close"></i> <?php echo e($item['status']); ?></span>
                              <?php elseif($item['status'] == 'Terkirim'): ?>
                              <span class="label label-info"><i class="fa fa-paper-plane"></i> <?php echo e($item['status']); ?></span>
                              <?php else: ?>
                              <span class="label label-success"><i class="fa fa-check-square"></i> <?php echo e($item['status']); ?></span>
                              <?php endif; ?>

                          </td>
                          <td>
                            <input type="hidden" name="status" value="<?php echo e($item['status']); ?>">
                            <button type="button" onclick="post_data_page('lpj/submitToKepsek','Data LPJ','formdataLpj','tambah','tbl_pmb_pajak','lpj')" class="btn btn-primary btn-xs">Submit</button>
                          </td>
                      </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </tbody>
                  </table>
                </form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headsecond', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\friends\resources\views/bendahara/lpj/lpjKelola/index.blade.php ENDPATH**/ ?>
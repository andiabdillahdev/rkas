<table id="tbl_kepsek" class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>Nama</th>
            <th>E-Mail</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>

    </tbody>
</table><?php /**PATH D:\friends\resources\views/administrator/sub_index/kepsek/index.blade.php ENDPATH**/ ?>
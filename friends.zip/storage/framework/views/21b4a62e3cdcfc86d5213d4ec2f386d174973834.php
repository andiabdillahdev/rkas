<table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Item</th>
        <th>Keterangan</th>
      </tr>
    </thead>
    <tbody>
    <tr>
        <td></td>
        <td>Nama</td>
        <td><?php echo e($data['nama']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Nomor Induk Pegawai</td>
        <td><?php echo e($data['nip']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Jenis Kelamin</td>
        <td><?php echo e($data['jk']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Tanggal Lahir</td>
        <td><?php echo e($data['tgl_lahir']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Agama</td>
        <td><?php echo e($data['agama']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Status</td>
        <td><?php echo e($data['status']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Masa Kerja</td>
        <td><?php echo e($data['masa_kerja']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Jumlah Jam</td>
        <td><?php echo e($data['jml_jam']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Tugas Tambahan</td>
        <td><?php echo e($data['tgs_tambahan']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Alamat</td>
        <td><?php echo e($data['alamat']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>No Telepon</td>
        <td><?php echo e($data['no_tlp']); ?></td>
    </tr>
    </tbody>
  </table><?php /**PATH F:\MyNewProject\friends\resources\views/administrator/pegawai/show.blade.php ENDPATH**/ ?>
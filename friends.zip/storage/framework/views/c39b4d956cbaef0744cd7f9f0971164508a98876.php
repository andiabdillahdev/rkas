<div id="modal_content" class="modal fade bs-example-modal-lg" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel">Modal title</h4>
        </div>
        <div class="modal-body" id="modal-body">

        </div>
      </div>
    </div>
  </div>
<?php /**PATH F:\MyNewProject\friends\resources\views/layouts/modal.blade.php ENDPATH**/ ?>
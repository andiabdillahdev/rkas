<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        h2{
            text-align: center;
        }
        ul{
            list-style: none;
        }
        #sdlabel{
            margin-left: 14px;
        }
        #kablabel{
            margin-left: 4px;
        }
        #provlabel{
            margin-left: 56px;
        }
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        th, td {
            padding: 20px;
        }
    </style>
</head>
<body style="font-size: 10px">
    <h2>Buku Pembantu Bank</h2>
    <ul>
        <li>Nama Sekolah <span id="sdlabel">: SDN NO. 112 SATTULU</span></li>
        <li>Desa/Kecamatan <span id="desalabel">: PATTONGKO/SINJAI TENGAH</span> </li>
        <li>Kabupaten/Kota <span id="kablabel">: SINJAI</span> </li>
        <li>Provinsi <span id="provlabel">: SULAWESI SELATAN</span> </li>
    </ul>

    <table width="100%">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Kode</th>
                <th>No Bukti</th>
                <th>Uraian</th>
                <th>Penerimaan(Debit)</th>
                <th>Pengeluaran(Kredit)</th>
                <th>Saldo</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $uangkas = 0;
            $saldoTotal = 0;
                foreach ($penerimaan as $key ) {
                   $uangkas += $key['nominal'];
                }  
            ?>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td>Saldo Awal</td>
                <td></td>
                <td></td>
                <td>
                    <?php echo e(number_format($uangkas)); ?>

                </td>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            if ($item['status_transaksi'] == 'Debit') {
                $uangkas = $uangkas + $item['nominal'];
            }else {
                $uangkas = $uangkas - $item['nominal'];
            }
        ?>
                <tr>
                    <td><?php echo e($item['tanggal']); ?></td>
                    <td><?php echo e($item['no_kode']); ?></td>
                    <td><?php echo e($item['no_bukti']); ?></td>
                    <td><?php echo e($item['uraian']); ?></td>
                    <td>
                        <?php if($item['status_transaksi'] == 'Debit'): ?>
                        <?php echo e(number_format($item['nominal'])); ?>    
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($item['status_transaksi'] == 'Kredit'): ?>
                        <?php echo e(number_format($item['nominal'])); ?>    
                        <?php endif; ?>
                    </td>
                    <td>     <?php echo e(number_format($uangkas)); ?></td>
                </tr>
                <?php
                    $saldoTotal += $uangkas;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td><?php echo e(number_format($saldoTotal)); ?></td>
          </tr>
        </tbody>
    </table>

<script src="<?php echo e(asset('assets/vendors/jquery/dist/jquery.min.js')); ?>"></script>
<script>
    $(function () {
        alert('cedfsdf');   
    })
</script>
</body>
</html>j<?php /**PATH F:\MyNewProject\friends\resources\views/bendahara/lpj/kasumum/pdfView.blade.php ENDPATH**/ ?>
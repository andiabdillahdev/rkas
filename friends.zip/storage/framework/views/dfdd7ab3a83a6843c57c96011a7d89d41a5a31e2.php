<table id="tbl_bendahara" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Nama</th>
                <th>E-Mail</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>

        </tbody>
</table><?php /**PATH F:\MyNewProject\friends\resources\views/administrator/sub_index/bendahara/index.blade.php ENDPATH**/ ?>
<table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Item</th>
        <th>Keterangan</th>
      </tr>
    </thead>
    <tbody>
    <tr>
        <td></td>
        <td>Nama</td>
        <td><?php echo e($data['nama']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Nomor Induk Siswa</td>
        <td><?php echo e($data['nis']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Kelas</td>
        <td><?php echo e($data['kelas']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Jenis Kelamin</td>
        <td><?php echo e($data['jk']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Tanggal Lahir</td>
        <td><?php echo e($data['tgl_lahir']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Agama</td>
        <td><?php echo e($data['agama']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Anak Ke</td>
        <td><?php echo e($data['anak_ke']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Status</td>
        <td><?php echo e($data['status']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Pendidikan Sebelumnya</td>
        <td><?php echo e($data['pend_sblmnya']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Alamat Siswa</td>
        <td><?php echo e($data['tgs_tambahan']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Ayah</td>
        <td><?php echo e($data['ayah']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Ibu</td>
        <td><?php echo e($data['ibu']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Wali Ayah</td>
        <td><?php echo e($data['wali_ayah']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>Wali Ibu</td>
        <td><?php echo e($data['wali_ibu']); ?></td>
    </tr>
    <tr>
        <td></td>
        <td>No Telepon</td>
        <td><?php echo e($data['no_telp']); ?></td>
    </tr>
    </tbody>
  </table><?php /**PATH F:\MyNewProject\friends\resources\views/administrator/siswa/show.blade.php ENDPATH**/ ?>
<div class="modal-content">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
    </button>
    <h4 class="modal-title" id="myModalLabel">Modal title</h4>
  </div>
  <div class="modal-body">
   
    <table id="rkas_header" class="table table-striped table-bordered">
      <thead>
          <tr>
            <th>ID</th>
            <th>Kode Rekening</th>
            <th>Kode</th>
            <th>Uraian</th>
          </tr>
      </thead>
      <tbody>
          
      </tbody>
  </table>
  

  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    <button type="button" class="btn btn-primary">Save changes</button>
  </div>
</div><?php /**PATH F:\MyNewProject\friends\resources\views/bendahara/lpj/kasumum/pilihrkas.blade.php ENDPATH**/ ?>
<div class="row" style="margin-left: 2px;">
    <a role="button" class="btn btn-primary btn-sm" onclick="action_staff('action_button_staff','Form Tambah Data Akun Staff')"><i class="fa fa-plus-square"></i> Tambah Data</a>
</div>
    <table id="tbl_user_staff" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Nama</th>
                <th>E-Mail</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>

        </tbody>
    </table><?php /**PATH F:\MyNewProject\friends\resources\views/administrator/sub_index/staff.blade.php ENDPATH**/ ?>
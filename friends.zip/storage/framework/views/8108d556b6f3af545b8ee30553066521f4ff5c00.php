<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        .text-center{
            text-align: center;
        }
        ul{
            list-style: none;
        }
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
    </style>
</head>
<body>

    <?php
    $totalPenerimaan = 0;
    $totalHarga = 0;
    $tarifHargaItem = 0;
    $bigTotal = 0;
    $TotalTriwulan = 0;
    $TotalTriwulan2 = 0;
    $TotalTriwulan3 = 0;
    $TotalTriwulan4 = 0;
?>
    
    <center><img src="<?php echo e(public_path('assets/images/tutwuri.png')); ?>" style="width: 150px" alt="" srcset=""></center>

    <h3 class="text-center">LAPORAN PERTANGGUNGJAWABAN (LPJ) <br> PENGGUNAAN DANA <br> DANA BANTUAN OPERASIONAL (BOS) <br> TAHUN ANGGARAN 2021 </h3>
    <ul>
        <?php $__currentLoopData = $sekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kolah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>NAMA SEKOLAH <span style="margin-left: 100px">: <?php echo e($kolah['nama']); ?></span> </li>
        <li>NISPN <span style="margin-left: 182px">: <?php echo e($kolah['nispn']); ?></span> </li>
        <li>NSS  <span style="margin-left: 200px">: <?php echo e($kolah['nss']); ?></span> </li>
        <li>ALAMAT <span style="margin-left: 160px">: <?php echo e($kolah['alamat']); ?></span> </li>
        <li>RT/RW <span style="margin-left: 180px">: <?php echo e($kolah['rt_rw']); ?></span> </li>
        <li>DUSUN <span style="margin-left: 180px">: <?php echo e($kolah['dusun']); ?></span> </li>
        <li>DESA <span style="margin-left: 190px">: <?php echo e($kolah['desa']); ?></span> </li>
        <li>KECAMATAN <span style="margin-left: 130px">: <?php echo e($kolah['kecamatan']); ?></span> </li>
        <li>KABUPATEN <span style="margin-left: 130px">: <?php echo e($kolah['kabupaten']); ?></span> </li>
        <li>PROVINSI <span style="margin-left: 155px">: <?php echo e($kolah['provinsi']); ?></span> </li>
        <li>KODEPOS <span style="margin-left: 155px">: <?php echo e($kolah['kodepos']); ?></span> </li>
        <li>NO REKENING <span style="margin-left: 120px">: <?php echo e($kolah['no_rekening']); ?></span> </li>
        <li>NAMA REKENING <span style="margin-left: 95px">: <?php echo e($kolah['nama_rekening']); ?></span> </li>
        <li>NAMA BANK <span style="margin-left: 130px">: <?php echo e($kolah['nama_bank']); ?></span> </li>
        <li>NPWP <span style="margin-left: 180px">: <?php echo e($kolah['npwp']); ?></span> </li>
        <li>E-MAIL SEKOLAH <span style="margin-left: 70px">: <?php echo e($kolah['email']); ?></span> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<br><br><br>
    <h4>PENERIMAAN</h4>
    <p><strong>Sumber Dana : </strong></p>

    <table style="width: 100%">
        <thead>
            <tr>
                <th>No Kode</th>
                <th>Penerimaan</th>
                <th>Jumlah</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $penerimaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $totalPenerimaan += $item['nominal'];
            ?>
            <tr>
                <td><?php echo e($item['kode']); ?></td>
                <td><?php echo e($item['keterangan']); ?></td>
                <td><?php echo e(number_format($item['nominal'])); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="2"><strong>Total Penerimaan</strong></td>
                <td> <strong>Rp. <?php echo e(number_format($totalPenerimaan)); ?></strong> </td>
            </tr>
        </tfoot>
    </table>

    <br><br><br>
    <h4>PENGGUNAAN DANA</h4>
    <p><strong>Sumber Dana : </strong></p>

    <table style="width: 100%;margin-top:40px">
        <thead>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th colspan="3" style="text-align: center">Rincian Perhitungan</th>
                <th></th>
                <th colspan="4" style="text-align: center">Triwulan</th>
            </tr>
            <tr>
              <th>Kode Rekening</th>
              <th>Kode Program</th>
              <th>Uraian</th>
              <th>Volume</th>
              <th>Satuan</th>
              <th>Tarif Harga</th>
              <th>Jumlah</th>
              <th>1</th>
              <th>2</th>
              <th>3</th>
              <th>4</th>
            </tr>
        </thead>
        <tbody id="tbodyRkas">
            <?php $__currentLoopData = $belanja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr style="background: #ffbacb">
                <td>-</td>
                <td><?php echo e($item['kode']); ?></td>
                <td><?php echo e($item['uraian']); ?></td>
                <td>-</td>
                <td>-</td>
                <td>
                    <?php
                        $kl = 0;
                        $totalMain = 0;
                        foreach ($item->subprogram as $key ) {
                            foreach ($key->itemprogram as $x ) {
                                $xx = 0;
                                $xxyy = 0;
                                foreach ($x->belanja as $key => $mainforbelanja) {
                                    $xx = $xx + $mainforbelanja->tarif_harga; 
                                    $xxyy += $mainforbelanja->tarif_harga * $mainforbelanja->volume;
                                }
                                $kl = $kl + $xx;
                                $totalMain = $totalMain + $xxyy;
                            }   
                        }       
                    ?>
                    <?php echo e(number_format($kl)); ?>

                </td>
                <td><?php echo e(number_format($totalMain)); ?></td>
                <td>
                    <?php
                        $main_tri1 = 0;
                        foreach ($item->subprogram as $key) {
                            foreach ($key->itemprogram as $ghj) {
                                $lps = 0;
                                foreach ($ghj->belanja as $getTriwulan1) {
                                   $lps += $getTriwulan1->triwulan1;
                                }
                                $main_tri1 += $lps;
                            }
                        }
                    ?>
                    <?php echo e(number_format($main_tri1)); ?>

                </td>
                <td>
                <?php
                        $main_tri2 = 0;
                        foreach ($item->subprogram as $key) {
                            foreach ($key->itemprogram as $ghj) {
                                $lps = 0;
                                foreach ($ghj->belanja as $getTriwulan2) {
                                   $lps += $getTriwulan2->triwulan2;
                                }
                                $main_tri2 += $lps;
                            }
                        }
                    ?>
                    <?php echo e(number_format($main_tri2)); ?>

                </td>
                <td>
                     <?php
                        $main_tri3 = 0;
                        foreach ($item->subprogram as $key) {
                            foreach ($key->itemprogram as $ghj) {
                                $lps = 0;
                                foreach ($ghj->belanja as $getTriwulan3) {
                                   $lps += $getTriwulan3->triwulan3;
                                }
                                $main_tri3 += $lps;
                            }
                        }
                    ?>
                    <?php echo e(number_format($main_tri3)); ?>

                </td>
                <td>
                    <?php
                        $main_tri4 = 0;
                        foreach ($item->subprogram as $key) {
                            foreach ($key->itemprogram as $ghj) {
                                $lps = 0;
                                foreach ($ghj->belanja as $getTriwulan4) {
                                   $lps += $getTriwulan4->triwulan4;
                                }
                                $main_tri4 += $lps;
                            }
                        }
                    ?>
                    <?php echo e(number_format($main_tri4)); ?>

                </td>
            </tr>
                <?php $__currentLoopData = $item['subprogram']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="background: #b8ffc5">
                    <td>-</td>
                    <td><?php echo e($value['kode']); ?></td>
                    <td><?php echo e($value['uraian']); ?></td>
                    <td>-</td>
                    <td>-</td>
                    <td>
                        <?php
                            $as = 0;
                            $totalSub = 0;
                            foreach($value->itemprogram as $key1) {
                                $df = 0;
                                $fsd= 0;
                                foreach($key1->belanja as $keyBelanja) {
                                    $df = $df + $keyBelanja->tarif_harga;
                                    $fsd += $keyBelanja->tarif_harga * $keyBelanja->volume;
                                }
                                $as = $as + $df;
                                $totalSub += $fsd;
                            }
                        ?>
                        <?php echo e(number_format($as)); ?>

                    </td>
                    <td><?php echo e(number_format($totalSub)); ?></td>
                    <td>
                        <?php
                        $tri1 = 0;
                        foreach ($value->itemprogram as $trivalue1) {
                            $trirow_1 = 0;
                            foreach($trivalue1->belanja as $keyTriwulan1){
                            $trirow_1 += $keyTriwulan1->triwulan1;
                            }
                            $tri1+= $trirow_1;
                        }
                        
                        ?>
                        <?php echo e(number_format($tri1)); ?>

                    </td>
                    <td>
                        <?php
                            $tri2 = 0;
                            foreach ($value->itemprogram as $trivalue2) {
                                $trirow_2 = 0;
                                foreach($trivalue2->belanja as $keyTriwulan2){
                                $trirow_2 += $keyTriwulan2->triwulan2;
                                }
                                $tri2+= $trirow_2;
                            }
                            
                        ?>
                        <?php echo e(number_format($tri2)); ?>

                    </td>
                    <td>
                         <?php
                            $tri3 = 0;
                            foreach ($value->itemprogram as $trivalue3) {
                                $trirow_3 = 0;
                                foreach($trivalue3->belanja as $keyTriwulan3){
                                $trirow_3 += $keyTriwulan3->triwulan3;
                                }
                                $tri3+= $trirow_3;
                            }
                            
                        ?>
                        <?php echo e(number_format($tri3)); ?>

                    </td>
                    <td>
                        <?php
                            $tri4 = 0;
                            foreach ($value->itemprogram as $trivalue4) {
                                $trirow_3 = 0;
                                foreach($trivalue4->belanja as $keyTriwulan4){
                                $trirow_3 += $keyTriwulan4->triwulan4;
                                }
                                $tri4+= $trirow_3;
                            }
                            
                        ?>
                        <?php echo e(number_format($tri4)); ?>

                    </td>
                </tr>
                <?php $__currentLoopData = $value['itemprogram']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="background: #ffffb8">
                    <td>-</td>
                    <td><?php echo e($result['kode']); ?></td>
                    <td><?php echo e($result['uraian']); ?></td>
                    <td>-</td>
                    <td>-</td>
                    <td>
                        <?php
                            $lo = 0;
                            $totalItem = 0;
                            foreach($result->belanja as $belanja1) {
                                $lo = $lo + $belanja1->tarif_harga;
                                $totalItem += $belanja1->tarif_harga * $belanja1->volume; 
                            }
                        ?>
                        <?php echo e(number_format($lo)); ?>

                    </td>
                    <td>
                    <?php echo e(number_format($totalItem)); ?>

                    </td>
                    <td>
                        <?php 
                            $tri1 = 0;
                            foreach($result->belanja as $belanja01) {
                                $tri1 = $tri1 + $belanja01->triwulan1;
                            }
                        ?>
                        <?php echo e(number_format($tri1)); ?>

                    </td>
                    <td>
                        <?php 
                            $tri2 = 0;
                            foreach($result->belanja as $belanja02) {
                                $tri2 = $tri2 + $belanja02->triwulan2;
                            }
                        ?>
                        <?php echo e(number_format($tri2)); ?>

                    </td>
                    <td>
                         <?php 
                            $tri3 = 0;
                            foreach($result->belanja as $belanja03) {
                                $tri3 = $tri3 + $belanja03->triwulan3;
                            }
                        ?>
                        <?php echo e(number_format($tri3)); ?>

                    </td>
                    <td>
                        <?php 
                            $tri4 = 0;
                            foreach($result->belanja as $belanja04) {
                                $tri4 = $tri4 + $belanja04->triwulan4;
                            }
                        ?>
                        <?php echo e(number_format($tri4)); ?>

                    </td>
                </tr>
                  <?php $__currentLoopData = $item['belanja']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemlx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($itemlx['id_item'] == $result['id']): ?>
                    <?php
                    $totalHarga = $itemlx['tarif_harga'] * $itemlx['volume'];
                        $bigTotal += $totalHarga;
                        $TotalTriwulan += $itemlx['triwulan1'];
                        $TotalTriwulan2 += $itemlx['triwulan2'];
                        $TotalTriwulan3 += $itemlx['triwulan3'];
                        $TotalTriwulan4 += $itemlx['triwulan4'];

                ?>
                    <tr>
                        <td><?php echo e($itemlx['kode_rekening']); ?></td>
                        <td><?php echo e($itemlx['kode']); ?></td>
                        <td><?php echo e($itemlx['uraian']); ?></td>
                        <td><?php echo e($itemlx['volume']); ?></td>
                        <td><?php echo e($itemlx['satuan']); ?></td>
                        <td><?php echo e(number_format($itemlx['tarif_harga'])); ?></td>
                        <td><?php echo e(number_format($totalHarga)); ?></td>
                        <td><?php echo e(number_format($itemlx['triwulan1'])); ?></td>
                        <td><?php echo e(number_format($itemlx['triwulan2'])); ?></td>
                        <td><?php echo e(number_format($itemlx['triwulan3'])); ?></td>
                        <td><?php echo e(number_format($itemlx['triwulan4'])); ?></td>
                    </tr>
                    <?php endif; ?>
                   
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="6" style="text-align: center;font-weight:bold">Jumlah</td>
                <td><?php echo e(number_format($bigTotal)); ?></td>
                <td><?php echo e(number_format($TotalTriwulan)); ?></td>
                  <td><?php echo e(number_format($TotalTriwulan2)); ?></td>
                  <td><?php echo e(number_format($TotalTriwulan3)); ?></td>
                  <td><?php echo e(number_format($TotalTriwulan4)); ?></td>
            </tr>
        </tbody>
    </table>

    <br><br><br>
    <h4>KAS UMUM</h4>
    <p><strong>Sumber Dana : </strong></p>

    <table width="100%">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Kode</th>
                <th>No Bukti</th>
                <th>Uraian</th>
                <th>Penerimaan(Debit)</th>
                <th>Pengeluaran(Kredit)</th>
                <th>Saldo</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $uangkas_ku = 0;
            $saldoTotal_ku = 0;
                foreach ($penerimaan as $key ) {
                   $uangkas_ku += $key['nominal'];
                }  
            ?>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td>Saldo Awal</td>
                <td></td>
                <td></td>
                <td>
                    <?php echo e(number_format($uangkas_ku)); ?>

                </td>
            </tr>
            <?php $__currentLoopData = $kasumum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            if ($item['status_transaksi'] == 'Debit') {
                $uangkas_ku = $uangkas_ku + $item['nominal'];
            }else {
                $uangkas_ku = $uangkas_ku - $item['nominal'];
            }
        ?>
                <tr>
                    <td><?php echo e($item['tanggal']); ?></td>
                    <td><?php echo e($item['no_kode']); ?></td>
                    <td><?php echo e($item['no_bukti']); ?></td>
                    <td><?php echo e($item['uraian']); ?></td>
                    <td>
                        <?php if($item['status_transaksi'] == 'Debit'): ?>
                        <?php echo e(number_format($item['nominal'])); ?>    
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($item['status_transaksi'] == 'Kredit'): ?>
                        <?php echo e(number_format($item['nominal'])); ?>    
                        <?php endif; ?>
                    </td>
                    <td>     <?php echo e(number_format($uangkas_ku)); ?></td>
                </tr>
                <?php
                    $saldoTotal_ku += $uangkas_ku;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td><?php echo e(number_format($saldoTotal_ku)); ?></td>
          </tr>
        </tbody>
    </table>


    <br><br><br>
    <h4>BUKU PEMBANTU BANK</h4>
    <p><strong>Sumber Dana : </strong></p>

    <table width="100%">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Kode</th>
                <th>No Bukti</th>
                <th>Uraian</th>
                <th>Penerimaan(Debit)</th>
                <th>Pengeluaran(Kredit)</th>
                <th>Saldo</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $uangkas_bk_pmb_pajak = 0;
            $saldoTotal_bk_pmb_pajak = 0;
                foreach ($penerimaan as $key ) {
                   $uangkas_bk_pmb_pajak += $key['nominal'];
                }  
            ?>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td>Saldo Awal</td>
                <td></td>
                <td></td>
                <td>
                    <?php echo e(number_format($uangkas_bk_pmb_pajak)); ?>

                </td>
            </tr>
            <?php $__currentLoopData = $bk_pmb_bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            if ($item['status_transaksi'] == 'Debit') {
                $uangkas_bk_pmb_pajak = $uangkas_bk_pmb_pajak + $item['nominal'];
            }else {
                $uangkas_bk_pmb_pajak = $uangkas_bk_pmb_pajak - $item['nominal'];
            }
        ?>
                <tr>
                    <td><?php echo e($item['tanggal']); ?></td>
                    <td><?php echo e($item['no_kode']); ?></td>
                    <td><?php echo e($item['no_bukti']); ?></td>
                    <td><?php echo e($item['uraian']); ?></td>
                    <td>
                        <?php if($item['status_transaksi'] == 'Debit'): ?>
                        <?php echo e(number_format($item['nominal'])); ?>    
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($item['status_transaksi'] == 'Kredit'): ?>
                        <?php echo e(number_format($item['nominal'])); ?>    
                        <?php endif; ?>
                    </td>
                    <td>     <?php echo e(number_format($uangkas_bk_pmb_pajak)); ?></td>
                </tr>
                <?php
                $saldoTotal_bk_pmb_pajak += $uangkas_bk_pmb_pajak;
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?php echo e(number_format($saldoTotal_bk_pmb_pajak)); ?></td>
            </tr>
        </tbody>
    </table>

       <br><br><br>
    <h4>BUKU PEMBANTU PAJAK</h4>
    <p><strong>Sumber Dana : </strong></p>


    <table width="100%">
        <thead>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th colspan="4">Penerimaan(Debit)</th>
                <th></th>
                <th></th>
            </tr>
            <tr>
                <th>Tanggal</th>
                <th>Kode</th>
                <th>No Bukti</th>
                <th>Uraian</th>
                <th>PPN</th>
                <th>PPh 21</th>
                <th>PPh 22</th>
                <th>PPh 23</th>
                <th>Pengeluaran(Kredit)</th>
                <th>Saldo</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $uangkas = 0;
            $saldoAwal = 0;
                foreach ($penerimaan as $key ) {
                   $uangkas += $key['nominal'];
                }
                 
            ?>
                 <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>Saldo Awal</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>
                        <?php echo e(number_format($uangkas)); ?>

                    </td>
                </tr>
            <?php $__currentLoopData = $bk_pmb_pajak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                if ($item['status_transaksi'] == 'Debit') {
                    $uangkas = $uangkas + $item['nominal'];
                }else {
                    $uangkas = $uangkas - $item['nominal'];
                }
            ?>
                <tr>
                    <td><?php echo e($item['tanggal']); ?></td>
                    <td><?php echo e($item['no_kode']); ?></td>
                    <td><?php echo e($item['no_bukti']); ?></td>
                    <td><?php echo e($item['uraian']); ?></td>
                    <td>
                        <?php if($item['status_transaksi'] == 'Debit' && $item['kode_pajak'] == 'PPN'): ?>
                        <?php echo e(number_format($item['nominal'])); ?>    
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($item['status_transaksi'] == 'Debit' && $item['kode_pajak'] == 'PPh 21'): ?>
                        <?php echo e(number_format($item['nominal'])); ?>    
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($item['status_transaksi'] == 'Debit' && $item['kode_pajak'] == 'PPh 22'): ?>
                        <?php echo e(number_format($item['nominal'])); ?>    
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($item['status_transaksi'] == 'Debit' && $item['kode_pajak'] == 'PPh 23'): ?>
                        <?php echo e(number_format($item['nominal'])); ?>    
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($item['status_transaksi'] == 'Kredit' && $item['kode_pajak'] == null): ?>
                        <?php echo e(number_format($item['nominal'])); ?>    
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e(number_format($uangkas)); ?>

                    </td>
                </tr>
                <?php
                   $saldoAwal +=  $uangkas;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>
                    
                </td>
                <td>
                    
                </td>
                <td>
                    
                </td>
                <td>
                    
                </td>
                <td>
                    
                </td>
                <td>
                    <?php echo e(number_format($saldoAwal)); ?>

                </td>
            </tr>
        </tbody>
    </table>

</body>
</html><?php /**PATH D:\friends\resources\views/bendahara/lpj/lpjKelola/pdflpj.blade.php ENDPATH**/ ?>
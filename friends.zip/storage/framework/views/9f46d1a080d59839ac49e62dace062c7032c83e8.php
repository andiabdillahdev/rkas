<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3>Detail Data Belanja</h3>
        </div>
      </div>

      <div class="clearfix"></div>

      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>Belanja Anggaran <small>Rincian Perhitungan</small></h2>
              <div class="clearfix"></div>
            </div>
            <div class="x_content">
             
                <table class="table table-bordered jambo_table bulk_action">
                    <thead>
                     <tr class="headings">
                         <th></th>
                         <th></th>
                         <th></th>
                         <th colspan="3" align="center">Rincian Perhitungan</th>
                         <th></th>
                         <th colspan="4" align="center">Triwulan</th>
                     </tr>
                      <tr class="headings">
                        <th>Kode Rekening</th>
                        <th>Kode Program</th>
                        <th>Uraian</th>
                        <th>Volume</th>
                        <th>Satuan</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>1</th>
                        <th>2</th>
                        <th>3</th>
                        <th>4</th>
                      </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td><?php echo e($data['main_program']['kode']); ?></td>
                            <td><?php echo e($data['main_program']['uraian']); ?></td>
                            <td></td>
                            <td></td>
                            <td><?php echo e(number_format($data->tarif_harga,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan1 + $data->triwulan2 + $data->triwulan3 + $data->triwulan4,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan1,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan2,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan3,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan4,2)); ?></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><?php echo e($data['sub_program']['kode']); ?></td>
                            <td><?php echo e($data['sub_program']['uraian']); ?></td>
                            <td></td>
                            <td></td>
                            <td><?php echo e(number_format($data->tarif_harga,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan1 + $data->triwulan2 + $data->triwulan3 + $data->triwulan4,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan1,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan2,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan3,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan4,2)); ?></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><?php echo e($data['item_program']['kode']); ?></td>
                            <td><?php echo e($data['item_program']['uraian']); ?></td>
                            <td></td>
                            <td></td>
                            <td><?php echo e(number_format($data->tarif_harga,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan1 + $data->triwulan2 + $data->triwulan3 + $data->triwulan4,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan1,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan2,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan3,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan4,2)); ?></td>
                        </tr>
                        <tr style="background:#f2f2f2;">
                            <td><?php echo e($data->kode_rekening); ?></td>
                            <td><?php echo e($data->kode); ?></td>
                            <td><?php echo e($data->uraian); ?></td>
                            <td><?php echo e($data->volume); ?></td>
                            <td><?php echo e($data->satuan); ?></td>
                            <td><?php echo e(number_format($data->tarif_harga,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan1 + $data->triwulan2 + $data->triwulan3 + $data->triwulan4,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan1,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan2,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan3,2)); ?></td>
                            <td><?php echo e(number_format($data->triwulan4,2)); ?></td>
                        </tr>
                    </tbody>
                  </table>

                  <div class="x_title">
                    <h2>Bukti Penggunaan Dana <small>Rincian Dokumen</small></h2>
                    <div class="clearfix"></div>
                  </div>

                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Item</th>
                        <th>Bukti Sekolah</th>
                        <th>Bukti Toko</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $data['bukti_penggunaan_dana']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td></td>
                            <td><?php echo e($item['keterangan']); ?></td>
                            <td> <a href="<?php echo e(asset('struk/sekolah/'.$item['bukti_sekolah'])); ?>" data-lightbox="bukti_sekolah" data-title="Bukti Sekolah"> <img width="100px" height="100px" src="<?php echo e(asset('struk/sekolah/'.$item['bukti_sekolah'])); ?>" alt=""> </a> </td>
                            <td> <a href="<?php echo e(asset('struk/sekolah/'.$item['bukti_sekolah'])); ?>" data-lightbox="bukti_toko" data-title="Bukti Toko"> <img width="100px" height="100px" src="<?php echo e(asset('struk/toko/'.$item['bukti_toko'])); ?>" alt=""> </a> </td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>

            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
  <!-- /page content -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
      $(function () {
        lightbox.option({
          'resizeDuration': 200,
          'wrapAround': true
        })
      })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.headfoot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\MyNewProject\friends\resources\views/administrator/rkas/belanja/show.blade.php ENDPATH**/ ?>
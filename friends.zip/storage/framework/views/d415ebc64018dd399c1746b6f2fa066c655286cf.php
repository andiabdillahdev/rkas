
    <table id="tbl_user_staff" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Nama</th>
                <th>E-Mail</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>

        </tbody>
    </table><?php /**PATH D:\friends\resources\views/administrator/sub_index/staff/staff.blade.php ENDPATH**/ ?>